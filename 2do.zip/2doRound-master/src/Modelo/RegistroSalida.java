/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author lurianne
 */
public class RegistroSalida {
    private int idRegistroSalida;
    private String hora;
    private int ci;

    public int getIdRegistroSalida() {
        return idRegistroSalida;
    }

    public void setIdRegistroSalida(int idRegistroSalida) {
        this.idRegistroSalida = idRegistroSalida;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public int getCi() {
        return ci;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }
    
    
}
