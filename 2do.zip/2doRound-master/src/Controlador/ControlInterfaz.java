
package Controlador;

import static Controlador.Conector.getConnection;
import Modelo.Empleado;
import Modelo.Dao.EmpleadoDao;
import Modelo.Dao.MaterialDao;
import Modelo.Dao.ProveedorDao;
import Modelo.Proveedor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import vista.ConsultaEmpleado;
import vista.IngresoAlmacen;
import vista.PantallaIngresoSalida;
import vista.RegistroSalida;
import vista.SalidaAlmacen;
import vista.SeleccionFuncion;



public class ControlInterfaz implements ActionListener {

    private SeleccionFuncion seleccionFuncion;
    private Conector c;
    private RegistroSalida registroSalida;
    private PantallaIngresoSalida ingresoSalida;
    private ConsultaEmpleado consultaEmpleado;
    private IngresoAlmacen ingresoAlmacen;
    private SalidaAlmacen salidaAlmacen;
    //private ConsultaEmpleado consultaEmp;
    public ControlInterfaz(SeleccionFuncion s)
    {
        this.seleccionFuncion=s;
        c=new Conector();        

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String orden=e.getActionCommand();
        System.out.println(orden);
        switch(orden){
            ////////////////////////////SOLO PARA ABRIR VENTANAS 
            case "Abrir registro ingreso":break;
            case "Abrir registro salida":abrirRegistroSalida();break;
            case "Abrir registro personal":abrirConsultaEmpleado();break;
            case "Abrir habilitados instancia":break;
            case "Abrir registro comedor":break;
            case "Abrir cronograma mantenimiento":break;
            case "Abrir ubicacion custodia bienes":break;
            case "Abrir materiales consumibles":abrirIngresoSalida();break;
            case "Abrir productos sin usar":break;
            case "Abrir computadoras mantenimiento":break;
            case "Abrir registro vacacion":break;
            case "Abrir registro ingreso almacen":abrirIngresoAlmacen();break;
            case "Abrir registro salida almacen":abrirSalidaAlmacen();break;
            ///////////////////////////////
            
            case "Sale trabajador":salidaTrabajador();break;
            case "Limpiar registro salida":limpiarRegistro();break;
            case "Acepta registro ingreso":aceptaIngresoAlmacen();break;
            case "Cancela registro ingreso almacen":cancelaIngresoAlmacen();break;
            case "Acepta registro salida":aceptaSalidaAlmacen();break;
            case "Cancela registro salida almacen":cancelaSalidaAlmacen();break;
            case "Realiza consulta empleado vigente":realizaConsulta();break;
            default :System.out.println("Error en actioncomand");break;    
        }        
    }
    public void abrirRegistroSalida()
    {   
        registroSalida=new RegistroSalida();
        registroSalida.setControlador(this);
        
    }
    public void salidaTrabajador()
    {
        int ci=registroSalida.getCi();
        Empleado e=new EmpleadoDao().getEmpleado(ci);
        if(e==null)
            registroSalida.ciInexistente();
        else{
            boolean salioAntes=ControlEmpleado.verificarSalidaPrevia(ci);
            if(salioAntes==false){
                SimpleDateFormat df = new SimpleDateFormat("YYYY/MM/dd hh:mm:ss");
                Calendar calendar = Calendar.getInstance();
                Date horaActual=calendar.getTime();
                String hora=(df.format(horaActual));
                if(ControlHora.saleAntes(horaActual)){
                    int ans=registroSalida.alerta();//si=0 ,no=1
                    if(ans==0){
                        new EmpleadoDao().marcarSalida(registroSalida.getCi(),hora);
                        registroSalida.exito();
                    }
                }
                else{
                    new EmpleadoDao().marcarSalida(registroSalida.getCi(),hora);
                    registroSalida.exito();
                }
            }   
            else{
                registroSalida.errorSalidaPrevia();
            }
        }
        limpiarRegistro();
   
    }
    public void limpiarRegistro()
    {
         registroSalida.limpiar();
    }

    private void abrirIngresoSalida() {
        ingresoSalida=new PantallaIngresoSalida();
        ingresoSalida.setControlador(this);
        
    }

    private void abrirConsultaEmpleado() {
        consultaEmpleado=new ConsultaEmpleado();
        consultaEmpleado.setControlador(this);
    }

    private void abrirIngresoAlmacen() {
        MaterialDao m= new MaterialDao();
        ArrayList a= new ArrayList <String> ();
        a=m.getListaMateriales();
        ProveedorDao p= new ProveedorDao();
        ArrayList b= new ArrayList <String> ();
        b=p.getListaMateriales();
        
        ingresoAlmacen=new IngresoAlmacen(b,a);
        ingresoAlmacen.setControlador(this);
        
    }

    private void abrirSalidaAlmacen() {
        MaterialDao m= new MaterialDao();
        ArrayList a= new ArrayList <String> ();
        a=m.getListaMateriales();
        EmpleadoDao p= new EmpleadoDao();
        ArrayList b= new ArrayList <String> ();
        b=p.getListaEmpleados();
        
        salidaAlmacen=new SalidaAlmacen(b,a);
        salidaAlmacen.setControlador(this);
    }

    private void aceptaIngresoAlmacen() {
        String prov= ingresoAlmacen.getProveedor();
        String mat=ingresoAlmacen.getProducto();
        int cant =ingresoAlmacen.getCantidad();
        System.out.println(prov+" "+mat+" "+cant);
        MaterialDao m=new MaterialDao();
        m.ingresoMaterial(prov, mat, cant);
        ingresoAlmacen.cerrar();
    }

    private void cancelaIngresoAlmacen() {
        ingresoAlmacen.cerrar();
    }

    private void aceptaSalidaAlmacen() {
        int ci= salidaAlmacen.getCiEmpleado();
        String mat=salidaAlmacen.getProducto();
        int cant =salidaAlmacen.getCantidad();
        System.out.println(ci+" "+mat+" "+cant);
        MaterialDao m=new MaterialDao();
        m.salidaMaterial(ci, mat, cant);   
        ingresoAlmacen.cerrar();
    }

    private void cancelaSalidaAlmacen() {
        salidaAlmacen.cerrar();
    }

    private void realizaConsulta() {
        System.out.println("............");
        EmpleadoDao e=new EmpleadoDao();
        ArrayList Emp=e.consultaEmpleadoActivo();
        consultaEmpleado.llenarJTable(Emp);
       
    }

}
